package com.bookserve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookserveApplicationTests {

	@Test
	void contextLoads() {
	}

}
